import cv2
import numpy as np
from sklearn.cluster import KMeans as DJ
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
import enchant
from itertools import islice

def seg_level_out(XX):
    xx = XX.copy()
    ht, wd = xx.shape[:2]
    for i in range(ht):
        for j in range(wd):
            r, g, b = xx[i][j][0], xx[i][j][1], xx[i][j][2]
            r1, r2, r3 = r / g, g / b, r / b
            r4 = round((r1 + r2 + r3) / 3, 1)
            if g > r and g > b:
                xx[i][j] = [0, 0, 0]
            elif r4 >= 1.2:
                xx[i][j] = [0, 0, 0]
            else:
                xx[i][j] = [255, 255, 255]
    return xx

def deep_joint_based_image_segmentation(slice_img):
    slice = cv2.cvtColor(slice_img, cv2.COLOR_BGR2GRAY)  # convert to gray scale image
    def grid_marking_points(G1_indx, slice_split_val, Output, val):
        aa = slice_split_val[val].flatten()
        for kk in range(len(G1_indx)):
            aa[G1_indx[kk]] = Output[val][kk]
        output = np.reshape(aa, (slice_split_val[val].shape[0], slice_split_val[val].shape[1]))
        return output

    def dj_segmented_output(dj_array, G1_indx, G2_indx, G3_indx, G4_indx, G5_indx, G6_indx, G7_indx, G8_indx, G9_indx):
        g1 = grid_marking_points(G1_indx, slice_split_val, Output, 0)
        g2 = grid_marking_points(G2_indx, slice_split_val, Output, 1)
        g3 = grid_marking_points(G3_indx, slice_split_val, Output, 2)
        g4 = grid_marking_points(G4_indx, slice_split_val, Output, 3)
        g5 = grid_marking_points(G5_indx, slice_split_val, Output, 4)
        g6 = grid_marking_points(G6_indx, slice_split_val, Output, 5)
        g7 = grid_marking_points(G7_indx, slice_split_val, Output, 6)
        g8 = grid_marking_points(G8_indx, slice_split_val, Output, 7)
        g9 = grid_marking_points(G9_indx, slice_split_val, Output, 8)
        grid_label = np.concatenate((g1, g2, g3, g4, g5, g6, g7, g8, g9))

        return grid_label




    #stepA: input image split into 9 grids
    slice_split=np.array_split(np.array(slice),9) # got 9 grid
    # stepB: Joining Phase #

    slice_split_val=np.array_split(np.array(slice),9)
    # aaa=np.concatenate(slice_split_val)

    # to find mean of grid
    g_value=[]
    for i in range(len(slice_split)):
        g=np.mean(slice_split[i])
        g_value.append(g)

    # joined with threshold +1or-1
    Grid_th=[]
    for i in range(len(g_value)):
        G=g_value[i]+1
        Grid_th.append(G)

    # below that threshold marked that points

    for j in range(len(slice_split)):
        grid1=slice_split[j]
        for k in range(grid1.shape[0]):
            for l in range(grid1.shape[1]):
                if grid1[k][l]<=Grid_th[j]:
                    slice_split[j][k][l]=True # mark that points

    # stepC: grid total region fusion part G9 X G9 #
    fusion_val=[]
    for ii in range(len(slice_split)):
        index_slice=np.where(slice_split[ii].flatten()==1)
        average_grid=[]
        for jj in range(len(index_slice[0])):
            average_grid.append(slice_split_val[ii].flatten()[index_slice[0][jj]])
        fusion_val.append(np.mean(average_grid))

    # fusion all points #
    fusion_slice=np.zeros([len(fusion_val),len(fusion_val)])+100000
    for m in range(fusion_slice.shape[0]):
        for n in range(fusion_slice.shape[1]):
            if n>m:
                fusion_slice[m][n]=fusion_val[n]-fusion_val[m]  # difference between  mean of grid

    # main contribution #

    Fi=3
    append_loc, append_grid=[], []

    for a in range(len(fusion_slice)-1): # grid range
        try:
            min_pt = []
            for c in range(len(fusion_slice[a])):
                if fusion_slice[a][c]<Fi  : # the minimum point less than 3
                    min_pt.append(fusion_slice[a][c]) # find minimum points

            min_g = np.min(min_pt)
        except:
            min_pt=fusion_slice[0][-1]
            min_g=fusion_slice[0][-1]
        loc=np.where(fusion_slice[a]==min_g) # get index of min points
        if len(loc[0])>1:
            ind=loc[0][0]
        else:
            ind=np.array([1])

        fusion_slice_copy=fusion_slice.copy()
        if (ind in append_loc):
            g = len(append_loc)
            end = 0
            while (len(append_loc)<=g):
                end += 1
                if (end>=len(fusion_slice_copy[a])): g = 0
                index = np.argmin(fusion_slice_copy[a])
                fusion_slice_copy = fusion_slice_copy.copy() # # if that index already have means change the next min value
                fusion_slice_copy[a][index] = 1000
                min_pt=np.min(fusion_slice_copy[a])
                list_loc=np.where(fusion_slice_copy[a]==min_pt)
                i = 0
                # fuse the region with least Fj #
                while (i < len(list_loc[0])):
                    if(list_loc[0][i] not in append_loc):
                        append_loc.append(list_loc[0][i])
                        append_grid.append(a)
                        i += len(list_loc[0])
                    i += 1
        else:
            try:
                append_loc.append(ind[0])
            except:
                append_loc.append(ind)
            append_grid.append(a)

    # to create the mappped points #
    MM_points=[] # selected grid (G0,G8), (G1,G7),(G2,G6),(G3,G5)
    for i in range(len(append_grid)):
        MM_points.append([append_grid[i], append_loc[i]])


    def find_mapping_grid(M1):

        #take selected grid and take mean of marked pixel #
        res_list1 = [i for i, value in enumerate(slice_split[M1[0]].flatten()) if value == 1]
        res_list2 = [i for i, value in enumerate(slice_split[M1[1]].flatten()) if value == 1]

        map_pt=[]
        for i in range(len(res_list1)):
            map_pt.append(slice_split_val[M1[0]].flatten()[ res_list1[i]])
        for j in range(len(res_list2)):
            map_pt.append(slice_split_val[M1[1]].flatten()[ res_list2[j]])
        mean_two_grid =np.mean(map_pt)
        return mean_two_grid

    res_mapped_ponts=[] # got mapped grid points
    for i in range(len(MM_points)):
        res_mean=find_mapping_grid(MM_points[i])
        res_mapped_ponts.append(res_mean)

    def find_missed_pixel_for_all_grid(slice_split_val,res_list0,val):
        res_points=[]
        point_index=[]
        for i in range(len(res_list0)):
            aa_split=slice_split_val[val].flatten()
            res_points.append(aa_split[res_list0[i]])
            point_index.append(res_list0[i])
        return res_points,point_index

     # to find misssed pixel #
    res_list0 = [i for i, value in enumerate(slice_split[0].flatten()) if value >= 1]
    res_list1 = [i for i, value in enumerate(slice_split[1].flatten()) if value >= 1]
    res_list2= [i for i, value in enumerate(slice_split[2].flatten()) if value >= 1]
    res_list3 = [i for i, value in enumerate(slice_split[3].flatten()) if value >= 1]
    res_list4 = [i for i, value in enumerate(slice_split[4].flatten()) if value >= 1]
    res_list5 = [i for i, value in enumerate(slice_split[5].flatten()) if value >= 1]
    res_list6 = [i for i, value in enumerate(slice_split[6].flatten()) if value >= 1]
    res_list7 = [i for i, value in enumerate(slice_split[7].flatten()) if value >= 1]
    res_list8 = [i for i, value in enumerate(slice_split[8].flatten()) if value >= 1]

    G1_missed, G1_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list0,0)
    G2_missed,G2_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list1,1)
    G3_missed,G3_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list2,2)
    G4_missed,G4_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list3,3)
    G5_missed,G5_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list4,4)
    G6_missed,G6_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list5,5)
    G7_missed,G7_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list6,6)
    G8_missed,G8_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list7,7)
    G9_missed,G9_indx=find_missed_pixel_for_all_grid(slice_split_val,res_list8,8)

    miss_pixels_for_all_grid=G1_missed+G2_missed+G3_missed+G4_missed+G5_missed+G6_missed+G7_missed+G8_missed+G9_missed
    concate_grid=[G1_missed,G2_missed,G3_missed,G4_missed,G5_missed,G6_missed,G7_missed,G8_missed,G9_missed]
    deep_point=miss_pixels_for_all_grid+res_mapped_ponts


    #find segmented points #
    S1=[]
    S2=[]
    S3=[]
    g_length=0
    for i in range(len(deep_point)):
        try:
            S2.append(np.mean([deep_point[i],deep_point[i+1]]))
        except:
            S2.append(np.mean([deep_point[i], deep_point[i - 1]]))
        S3.append(deep_point[i])
        if deep_point[i] in concate_grid[g_length]:
            S1.append(g_length)
            g_length+=1
            if g_length>len(concate_grid)-1:
                g_length-=1
        else:
            S1.append(g_length)

    # deeppoints X segpoints #
    S1=np.asarray(S1)
    S2=np.asarray(S2)
    S3=np.asarray(S3)
    S1=S1.reshape(-1,1)
    S2=S2.reshape(-1,1)
    S3=S3.reshape(-1,1)
    sss=np.concatenate([S1,S2,S3], axis=1)
    # slice = cv2.adaptiveThreshold(slice, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)

    deep_joint_points = DJ(n_clusters=4,random_state=0)
    a = deep_joint_points.fit(np.reshape(slice.flatten(),(len(slice.flatten()),1)))
    centroids = deep_joint_points.cluster_centers_
    centroids=centroids.flatten()
    sort_c=centroids.copy()
    sort_c=np.sort(sort_c)
    centroids_1=[]
    for i in range(len(sort_c)):
        centroids_1.append(np.where(sort_c==centroids[i]))

    centroids_=centroids_1
    labels = deep_joint_points.labels_
    label_arr=np.ones_like(labels)*1000
    for i in range(len(labels)):
        if labels[i]==0:
            label_arr[i]=centroids_[0][0]
        elif labels[i]==1:
            label_arr[i]=centroids_[1][0]
        elif labels[i]==2:
            label_arr[i]=centroids_[2][0]
        else:
            label_arr[i] =centroids_[3][0]

    label_arr=np.reshape(label_arr,(slice.shape[0], slice.shape[1]))
    fin_label=label_arr.astype('uint8')
    fin_label[fin_label<np.max(labels)]=0
    fin_label =seg_level_out(slice_img)

    def euclid_dist(t1, t2):
        return np.sqrt(((t1 - t2) ** 2))

    def levenshtein_dist(a,b):
            leven_ot=enchant.utils.levenshtein([a, a], [b, b])
            return leven_ot


    seg=[]
    for deep in range(len(deep_point)):
        ED=euclid_dist(deep_point[deep],np.mean(sss[deep]))
        LD=levenshtein_dist(deep_point[deep], np.mean(sss[deep]))
        W1=np.random.uniform(0,1)
        W2 = np.random.uniform(0, 1)
        fin_seg_pt=W1*ED+W2*LD
        seg.append(fin_seg_pt)

    dj = DJ(n_clusters=5, random_state=0).fit(sss)
    k_lab=dj.labels_
    length_to_split=[len(G1_missed),len(G2_missed),len(G3_missed),len(G4_missed),len(G5_missed),len(G6_missed),len(G7_missed), len(G8_missed),len(G9_missed)]

    # Using islice
    Inputt = iter(k_lab)
    Output = [list(islice(Inputt, elem))
              for elem in length_to_split]
    seg_roi=dj_segmented_output(fin_label,G1_indx,G2_indx,G3_indx,G4_indx,G5_indx,G6_indx,G7_indx,G8_indx,G9_indx)

    return seg_roi

