import pandas as pd
import glob, re
from deep_joint_segmentation import *
import cv2
import TunicateSwarmAlgorithm

def main():
    dir_path='DB//Train_images//*.jpg'
    train_lab=pd.read_csv('train.csv')

    # get the labels
    train_lab=train_lab.drop(['image_id'],axis=1)
    training_label=train_lab.values

    fin_lab=[]  # get the final target
    for k in range(len(training_label)):
        lab=training_label[k].tolist().index(1)
        fin_lab.append(lab)
    np.save('fin_lab', fin_lab)

    Pmin, Pmax, x, max_itr = 1, 50, 0, 50  # initial, subordinate speeds, initial parameters, max. iteration
    sca_sa_bf = TunicateSwarmAlgorithm.prop_sca_tunicate_swarm_algorithm(Pmin, Pmax, x, max_itr)
    np.save('tssca_bs', sca_sa_bf)

    fin_feat=[]
    for img in glob.glob(dir_path): # get all the image from folder
        cv_img = cv2.imread(img) # read image one by one
        rs_input=cv2.resize(cv_img,(512,512))  # resize the images

        ############ PRE_PROCESSING ##################

        # Gaussian Blur
        pp_img = cv2.GaussianBlur(rs_input, (7, 7), 0)

        ############ SEGMENTATION: Deep Joint Segmentation ##################

        dj_seg=deep_joint_based_image_segmentation(pp_img)

        dj_seg_rgb_fin = cv2.resize(dj_seg,(128, 128))  # reshape into 128 X 128
        fin_feat.append(dj_seg_rgb_fin)

        np.save('fin_features',fin_feat)

    feat = np.load('fin_features.npy')
    lab = np.load('fin_lab.npy')
    return feat, lab,sca_sa_bf




