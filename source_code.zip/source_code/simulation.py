import random
import wsnsimpy.wsnsimpy_tk as wsp

def simulation_run(x_value, y_value, n_cluster, rounds, BS, col_n, CH, cluster_group, dead_nodes, Final_path):

    class MyNode(wsp.Node):
        tx_range = 50

        ###################
        def run(self):  # loop until nodes
            yield self.timeout(3)  # shows created nodes
            for i in range(len(CH)):
                for j in range(len(cluster_group)):
                    if cluster_group[j] == CH[i]:  # checks the node is grouped with which cluster head
                        if self.id is j:
                            self.scene.nodecolor(self.id, R[i], G[i],
                                                 B[i])  # displays nodes in diff clusters with diff colors
                            self.scene.nodewidth(self.id, nod_wid)
                            if self.id is CH[i]:
                                self.scene.nodewidth(self.id, CH_wid)  # if node is Cluster head, node width is more
                            yield self.timeout(5)  # time to show the clustered nodes - initial (dead nodes will be greyed after 5s)

            if self.id is BS:
                self.scene.nodecolor(self.id, 0, 0, 0)  # if node is Base station, node color => black, with width 15
                self.scene.nodewidth(self.id, 15)
            else:
                for i in range(len(dead_nodes)):  # dead node will be disabled
                    if (self.id is dead_nodes[i]) and (self.id != 0):
                        self.scene.nodecolor(self.id, .7, .7, .7)  # else, node color => grey (disable)

            for i in range(len(Final_path) - 1):
                if self.id is Final_path[i]:
                    self.start_process(self.start_send_data(Final_path[i + 1]))  # source, destination

        ###################
        def start_send_data(self, dest):
            #
            seq = 0

            while True:
                yield self.timeout(0.5)  # transmission will be displayed after 0.5s
                self.scene.clearlinks()
                d = random.uniform(.3, .35)  # uniform value between 0.5 - 0.6
                yield self.timeout(d)  # timeout of the link between nodes
                self.send_data(dest)  ##################source, dest
                seq += 1

        ###################
        def send_data(self, dest):
            self.send(dest, msg='data', src=self.id)


    WS = col_n * 70  # window size
    nod_wid, CH_wid = 2, 7  # width of node & cluster head
    R, G, B = [1, 0, 0.8, 1, 0.6, 0.2, 1], [0, 0.4, 0.5, 0, 0, 0, 0.3], [0, 0, 0.1, 0.5, 0.7, 0.3,
                                                                         0]  # color for clusters

    # simulation will display for 30s
    sim = wsp.Simulator(until=15, timescale=1, visual=True, terrain_size=(WS, WS), title="Round " + str(
        rounds))  # simulation window (30s,True - to display, ter -- wnd. size, tit -- wnd. title)

    for i in range(len(x_value)):  # x columns1
        px, py = x_value[i], y_value[i]
        sim.add_node(MyNode, (px, py))  # create node at (px,py)

    # start the simulation
    sim.run()