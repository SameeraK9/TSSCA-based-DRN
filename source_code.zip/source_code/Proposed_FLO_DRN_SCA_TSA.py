import numpy, random, math
import Main_Lion_optimization
import process
import Deep_Residual_network
from sklearn.model_selection import train_test_split


def func(rounds, nodes, n_cluster, energy, data_pack, x_value, y_value, bs, i, pop, xt, xr, col_n,tr_per,ACC, SEN, SPE,
         simulation_result):

    # distance between nodes
    def distance(p1, p2):
        dist = numpy.sqrt((numpy.square(x_value[p2] - x_value[p1])) + (numpy.square(y_value[p2] - y_value[p1])))
        return dist

    # calculate node energy
    def calc_node_en(np, prev_en, x_t, x_r):

        en = prev_en.copy()  # copy of previous round energy
        m, n = 0.0005, 1000  # normalizing factor

        # energy drop for all nodes
        for ed in range(len(np) - 1):
            y = data_pack[np[ed]]  # no. of transmitted bits
            if ed == 0:  # source node
                if en[np[ed]] > 0:
                    dt = distance(np[ed], np[ed + 1]) / n  # distance to send the data
                    E = en[np[ed]] - (x_t * y) * dt  # only send the data to head
                    if E > 0: en[np[ed]] = E
                    else: en[np[ed]] = 0
                else:
                    en[np[ed]] = 0

            else:  # other nodes in path
                if np[ed] > 0:  # if 0 then no path
                    if en[np[ed]] > 0:
                        dt, dr = distance(np[ed], np[ed + 1]) / n, distance(np[ed], np[ed - 1]) / n  # distance to send & receive the data
                        E = en[np[ed]] - (x_r * y) * dr - (x_t * y) * dt  # receive & send
                        if E > 0: en[np[ed]] = E
                        else: en[np[ed]] = 0
                    else:
                        en[np[ed]] = 0
        return en

    # calculate node delay & throughput
    def calc_node_de_tp(en, data):
        de, tp = [], []
        n_packet, packet_received = 0, 0  # total packets, packets received
        for dt in range(len(en)):  # to the size of the node
            r = random.uniform(-1, 1)
            row = numpy.abs(((1.0 - en[dt]) * data[dt]) + r)
            lam = data[dt]
            n_packet = n_packet + data[dt]
            packet_received = packet_received + (en[dt] * data[dt])
            tp.append((en[dt] * data[dt]) / data[dt])
            d = row / lam
            if(d<1):de.append(d)
            else:de.append(1)
        return de, tp

    # Group with Cluster Head
    def node_clustering(n, CH):
        clustered = []
        for i in range(n):
            tem = []  # tem array to store the distance value
            for j in range(len(CH)):
                tem.append(
                    distance(i, CH[j]))  # distance calculation between cluster head & nodes except base station
            min_index = numpy.argmin(tem)
            clustered.append(CH[min_index])  # grouped cluster head is added
        clustered.append(bs)  # added base station at last separately
        return clustered

    # Path detection
    def detection(opt_nodes, base, en, pn, n_c, nodes):

        pth = []
        pth.append(0)  # source
        if(n_c>len(opt_nodes)): n_c = len(opt_nodes)    # non dead nodes

        ################ Cluster Head selection by Lion optimization #########################
        print('length of opt_nodes',len(opt_nodes))
        cluster_head = Main_Lion_optimization.fractional_LOA(opt_nodes, pn, en,  x_value, y_value, n_c, nodes, base)  #---------- bs
        grp = node_clustering(nodes, cluster_head)  # cluster head of the nodes

        ############### Path detection by Proposed Lion optimization #############################
        opt_path = Main_Lion_optimization.fractional_LOA(cluster_head, pn, en, x_value, y_value, n_c, nodes, base) # ------------bs
        for op in range(len(opt_path)):
            pth.append(opt_path[op])

        pth.append(base)  # destination
        pth = numpy.unique(pth)
        pth.sort()
        return cluster_head, grp, pth.tolist()

    # nodes other than dead nodes
    def get_active_nodes(en):
        opt_n = []
        for o in range(len(en)):
            if (o > 0) and (en[o] > 0):  # node with energy(not the dead node)
                opt_n.append(o)  # nodes other than source & destination
        return opt_n

    # get non dead nodes
    opt_nodes = get_active_nodes(energy)

    # Path from source to destination
    round_energy= energy.copy()
    if(len(opt_nodes) > 0):
        ch, cluster_group, path = detection(opt_nodes, bs, energy, pop, n_cluster, nodes)
        round_energy = calc_node_en(path, energy, xt, xr)  # energy of nodes after the transmission

    # results for simulation
    if (i == rounds-1): # at round 500
        dead_node = []  # nodes with no energy
        for j in range(len(round_energy)):
            if (round_energy[j] == 0):
                dead_node.append(j)

        Feature, label, BS_tssca= process.main()
        x_train, x_test, y_train, y_test = train_test_split(Feature, label, test_size=1 - tr_per,
                                                            random_state=123)  # splitting training & testing data
        _,acc, sens,spec=Deep_Residual_network.classify(x_train, y_train, x_test, y_test, BS_tssca.tolist())
        ACC.append(acc)
        SEN.append(sens)
        SPE.append(spec)

        simulation_result.append(x_value)   # nodes x-axis value
        simulation_result.append(y_value)   # nodes y-axis value
        simulation_result.append(n_cluster) # no. of cluster heads
        simulation_result.append(i)         # no. of rounds
        simulation_result.append(bs)        # Base station
        simulation_result.append(col_n)     # no. of grid columns in simulation window
        simulation_result.append(ch)        # Cluster head nodes
        simulation_result.append(cluster_group)  # nodes grouped with cluster heads
        simulation_result.append(dead_node)  # dead nodes (nodes with energy 0)
        simulation_result.append(path)       # transmission path of last node

    return round_energy


