import numpy as np

# distance between nodes
def distance(p1, p2, x_value, y_value):
    dist = np.sqrt((np.square(x_value[p2] - x_value[p1])) + (np.square(y_value[p2] - y_value[p1]))) # distance formula
    return dist


# Node grouping
def node_clustering(n, CH, bs, xv, yv):
    clustered = []
    for i in range(n):
        tem = []  # tem array to store the distance value
        for j in range(len(CH)):
            tem.append(distance(i, CH[j], xv, yv))  # distance calculation between cluster head & nodes except base station
        min_index = np.argmin(tem)
        clustered.append(CH[min_index])  # grouped cluster head is added
    clustered.append(bs)  # added base station at last separately
    return clustered


# summation of node energy
def calc_energy(nodes, en):
    en_summ = 0
    for i in range(len(nodes)):
        en_summ += en[nodes[i]]
    return en_summ


# distance calculation
def calc_dist(soln, cluster_node, xv, yv):
    ED_summ, f = 0, 100     # F => Normalization
    for i in range(len(soln)):
        cl_summ = 0
        for j in range(len(cluster_node[i])):
            cl_summ += distance(soln[i], cluster_node[i][j], xv, yv) / f     # distance (nodes & clustered nodes)
        ED_summ += cl_summ
    return ED_summ


# delay calculation
def calc_delay(M):
    M_summ, Max_M = 0, []
    for i in range(len(M)): Max_M.append(len(M[i]))     # nodes in each cluster
    for i in range(len(M)):
        M_summ += (len(M[i])/max(Max_M))    # M[i] => nodes in that cluster
    return M_summ


# grouping nodes
def group_nodes(nodes, cg):
    nodes_clustered = []
    for i in range(len(nodes)):
        tem = []
        for j in range(len(cg) - 1):    # -1, since last node is base station
            if (nodes[i] == cg[j]):     # node in that cluster
                tem.append(j)
        nodes_clustered.append(tem)     # group nodes in same cluster
    return nodes_clustered


# fitness calculation
def func(soln, opt_node, en, nodes, bs, xv, yv):

    fit = []
    for i in range(len(soln)):
        grp = node_clustering(nodes, soln[i], bs, xv, yv)  # soln. with nodes
        nodes_n_cluster = group_nodes(soln[i], grp)  # group the nodes

        H, K = len(soln[i]), len(opt_node)  # soln. size, no. of nodes in soln.
        E = calc_energy(soln[i], en) / H  # Energy
        D = calc_dist(soln[i], nodes_n_cluster, xv, yv) / (H * K)  # distance
        d = calc_delay(nodes_n_cluster) / H  # delay
        M = (E + (1 - D) + d) / 3  # Fitness formula
        fit.append(M)
    fit=np.array(fit)
    fit1=fit.reshape(-1,1)
    return fit1
