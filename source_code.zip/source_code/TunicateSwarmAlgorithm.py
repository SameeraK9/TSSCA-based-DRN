import Fitness, random as r
import numpy as np
import math

Pmin, Pmax, x, max_itr = 1, 4, 0, 2 # initial, subordinate speeds, initial parameters, max. iteration

def tunicate(n):
    pop = []
    for i in range(n):
        pop.append(r.random())  # random
    return pop

def prop_sca_tunicate_swarm_algorithm(Pmin, Pmax, x, max_itr ):
    n = 1              # dimension of population
    Pp = tunicate(n)    # initiate tunicate population
    Swarm = 0           # position
    FS_best = 1000

    while(x < max_itr):
        for i in range(2):  # Looping for compute swarm behavior
            FS, Ppx,best_index = Fitness.func(Pp)  # Calculate the fitness values of each search agent

            if (FS<FS_best):
                FS_best = FS
                Ppx_best = Ppx

            # Jet propulsion behavior
            c1, c2, c3, rand = r.random(), r.random(), r.random(), r.random()  # random in range(0, 1)
            # 𝑀  represents the social forces between search agents
            # Avoiding the conflicts among search agents
            M = (Pmin + c1 * Pmax - Pmin) #  social forces b/w search agents, water flow Eq.4
            F=(2 * c1) #Eq.3
            # 𝐺 is the gravity force and⃗𝐹shows the water flow advectionin deep ocean.
            # The variables𝑐1,𝑐2, and𝑐3are random numbers lie inthe range of[0,1]
            G = c2 + c3 - F  # gravity force Eq2
            # calculation of new search agent position #
            A = G / M  # for calc. of new search agent position Eq.1

            # Movement towards the direction of best neighbour
            PD = np.abs(FS - rand * Ppx)  # distance between the food source and search agent Eq.5


            ######################  Tunicate Swarm Sine Cosine Algorithm ##########################
            # search agent can maintain its position towards the best searchagent
            # Converge towards the best search agent
            r1=np.random.uniform(0,1)
            r2 = np.random.uniform(0, 1)
            r3 = np.random.uniform(0, 1)

            I=rand
            if (I >= 0.5):
                ########### update the equation ##############
                Swarm +=  FS + A * ((FS*(1-r1*math.sin(r2)) - I*(Swarm - r1*r3*math.sin(r2)*PD) )/ (1- r1 *math.sin(r2)))
            else:
                Swarm += FS - A * ((FS * (1 - r1 * math.sin(r2)) - I * (Swarm - r1 * r3 * math.sin(r2) * PD)) / (
                            1 - r1 * math.sin(r2)))

        # Swarm behaviour
        Ppx = Swarm / (2 + c1) # formula is proposed to define the swarm behavior of tunicate: Eq.7
        Swarm = 0
        Pp[best_index] = Ppx
        x += 1

    return FS_best


