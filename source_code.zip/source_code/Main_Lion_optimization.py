import numpy as np, random
from torch import randperm
import Lion_simulation_fitness

def  fractional_LOA(opt_nodes, pn, en,  x_value, y_value, nc, nodes, base):
    def rand():
        return np.random.random((1, 1))

    def fit(inp):
        f_val=np.random.random((len(inp),1)) # (5*1)
        return f_val

    def liongen(xmin,xmax,siz):
        lion = xmin + ((xmax-xmin)*np.random.random((1,siz)))
        return lion
    def mutation (cub, rate, xmin, xmax):

        len1=len(cub[0,:])# (cub[0,:].shape[1])
        point = np.max([1,int(np.round(rate*float(len1)))])
        new_cub=[]
        for j in range(0,len(cub[:,1])):#= 1:numel(cub[:,1].numel())
            new_cub.append(cub[j, :])
            for i in range(0,point):#= 1:point
                if i==0:
                    new_cub=np.asarray(new_cub)
                mut_point = int(np.asarray(np.round((((len(cub[0,:]))-1)*np.random.random((1,1))))))
                new_cub[j,mut_point]= xmin[0,mut_point]+(xmax[0,mut_point]-xmin[0,mut_point])*float(np.random.random((1,1)))

        new_cub = np.round(new_cub)
        return new_cub
    def lion(init_lion,xmin,xmax,max_eval):
        xmin = xmin[0,:].reshape(1, xmin[0,:].shape[0])
        xmax = xmax[0,:].reshape(1, xmax[0,:].shape[0])

        Mature_age = 3
        max_strength = 3
        gmax = 10
        mutation_rate = 0.15
        Max_age = 3
        eval = 0
        siz = 5
        # init_fit = fit(init_lion)
        init_fit =Lion_simulation_fitness.func(init_lion, opt_nodes, en, nodes, 100, x_value, y_value)
        init_val = np.argsort(init_fit.T)
        init_val_1=init_val[0]
        male_in = init_lion[init_val_1[0],:]
        female_in = init_lion[init_val_1[1],:]

        ########Nomadic lion Generation##########
        nomadic_pool = 0*np.ones([2,siz],dtype = float)
        nomadic_fit = 0*np.ones([2,1],dtype = float)#zeros(1, 2)
        nomadic_pool[0,:] = liongen(xmin, xmax, siz)
        SD=nomadic_pool[0,:].reshape(1,nomadic_pool.shape[1])
        nomadic_fit[0, 0]= fit(SD)
        # nomadic_fit[0, 0] =Lion_simulation_fitness.func(SD, opt_nodes, en, nodes, 100, x_value, y_value)

        # nomadic_fit[0, 0]=fval
        eval = eval + 1
        mat = 0
        gen = 0
        final = []
        plot_eval = []
        trial = 0
        flag = 0
        #########  Initial Lion Generation  ######
        plot_eval = [plot_eval,1]
        male_in=male_in.reshape(1,male_in.shape[0])
        female_in=female_in.reshape(1,female_in.shape[0])
        try:
            male_fit = Lion_simulation_fitness.func(male_in, opt_nodes, en, nodes, 100, x_value, y_value)[0][0]
            female_fit =Lion_simulation_fitness.func(female_in, opt_nodes, en, nodes, 100, x_value, y_value)

        except:
            male_fit = fit(male_in)
            female_fit = fit(female_in)

        trial_fit = male_fit

        eval = eval + 2
        ########   Iterative Process  ##############
        for mx in range(0,max_eval):
            ########  Age   Declaration  ############
            if (trial_fit == male_fit) or (trial_fit < male_fit):
                trial = trial + 1
            else:
                trial = 0
                trial_fit = male_fit
            ######### Fertility Evaluation  ##########
            if mat > max_strength:
                f = 0
                g = 0
                while (f == 0) and  (g < gmax):
                    g = g + 1
                    new_female = female_in
                    point1 = np.asarray(randperm(siz)).T
                    point= point1[0]
                    val_1=xmax[0,point]
                    val_2=(xmin[0,point])
                    try:

                        # ################ Fractional Lion Optimization #####################
                        theta=1
                        r2= np.random.randint(0,1)
                        val_3=( theta * male_in[0, point] + (1/2)* theta*male_in[0, point-1] + (0.1* r2-0.05)  * (male_in[0, point] - rand() * female_in[0, point]))
                        # Where male_in[0, point] is  defined  as  the  current  male
                        # Where male_in[0, point-1] is  defined  as  the  existing  male

                    except:
                        try:
                            male_in = male_in.reshape(1, male_in.shape[0])
                            val_3 = (female_in[0, point] + (-0.05 + 0.1 * rand()) * (male_in[0, point] - rand() * female_in[0, point]))
                        except:
                            female_in = female_in.reshape(1, female_in.shape[0])
                            val_3 = (female_in[0, point] + (-0.05 + 0.1 * rand()) * (male_in[0, point] - rand() * female_in[0, point]))

                    val_4=np.max([(val_2),int(val_3)])
                    val_5=np.min([(val_1),(val_4)])
                    new_female[0, point] = val_5#np.min([xmax[0,point], np.max(float(xmin[0,point]),( female_in[0, point] + (-0.05 + 0.1 * rand()) * (male_in[0, point] - rand() * female_in[0, point])))])
                    try:
                        new_fit =Lion_simulation_fitness.func(new_female, opt_nodes, en, nodes, 100, x_value, y_value)
                    except:
                        new_fit = fit(new_female)  # fitness for female
                    eval = eval + len(new_fit)
                    if new_fit < female_fit:
                        f = 1
                        female_in = new_female
                        female_fit = new_fit
                        mat = 0
            ######   Lion mating  ##########
            ###### Crossover   ############
            cubpool = 0*np.ones([8,siz],dtype = float)#zeros(8, siz)
            # randperm=np.random.uniform(0,1,size=(cubpool.shape))
            FV=(cubpool.shape[0]) / 2
            for i in range(0,int(FV)):
                vect = np.asarray(randperm(siz))#, randi(siz - 1))
                vect = vect.reshape(1, vect.shape[0])
                cubpool[i,:] = female_in

                for j in range(0,len(vect)):
                    try:
                        cubpool[i, vect[0,j]] = male_in[0,vect[0,j]]
                    except:
                        male_in = male_in.reshape(1, male_in.shape[0])
                        cubpool[i, vect[0, j]] = male_in[0, vect[0, j]]


            ###########  Mutation    ############
            for i in range(0,int(FV)) :
                cub_vect = cubpool[i,:].reshape(1, cubpool[i,:].shape[0])
                nc = mutation(cub_vect, mutation_rate, xmin, xmax)
                cubpool[4 + i,:]=nc
            mat = mat + 1
            cub_age = 0
            ##########    Finding male and female cubs    ################
            try:
                fit1 =Lion_simulation_fitness.func(cubpool, opt_nodes, en, nodes, 100, x_value, y_value)
            except:
                fit1 = fit(cubpool)
            idx1 = np.argsort(fit1.T)
            idx = idx1[0]
            eval = eval + len(fit1)
            male_cub = cubpool[idx[0],:]
            female_cub = cubpool[idx[1],:]
            cubpool_malefit = float(fit1[idx[0]])
            cubpool_femalefit =float( fit1[idx[1]])
            ##########Territorial Defense##############
            flag1 = 0
            while flag1 == 0:
                cub_age = cub_age + 1
                male_rate = 0.15
                female_rate = 0.15
                try:
                    male_cub = male_cub.reshape(1, male_cub.shape[0])
                except:
                    male_cub=male_cub
                s_male = mutation(male_cub, male_rate, xmin, xmax)
                s_malefit = fit(s_male)
                # s_malefit =Lion_simulation_fitness.func(s_male, opt_nodes, en, nodes, 100, x_value, y_value)
                eval = eval + len(s_malefit)
                if cubpool_malefit > s_malefit:
                    male_cub = s_male
                    cubpool_malefit = s_malefit
                try:
                    female_cub = female_cub.reshape(1, female_cub.shape[0])
                    s_female = mutation(female_cub, female_rate, xmin, xmax)
                    s_femalefit = Lion_simulation_fitness.func(s_female, opt_nodes, en, nodes, 100, x_value, y_value)
                except:
                    female_cub=female_cub
                    s_femalefit = fit(s_female)
                    eval = eval + fit(s_femalefit)
                if cubpool_malefit > s_femalefit:
                    female_cub = s_female
                    cubpool_femalefit = s_femalefit
                ########   Entrance of Nomadic Lion   ###########
                ####### Nomadic  Lion Generation########
                if trial > Max_age: #% Checking laggardness rate
                    nomadic_lion = mutation(male_in, 1 - mutation_rate, xmin, xmax)
                else:
                    nomadic_lion = liongen(xmin, xmax, siz)
                #########   New Survival Fight  #######
                nomadic_pool[1,:] = nomadic_lion
                Nom_pool = nomadic_pool[1,:].reshape(1, nomadic_pool[1,:].shape[0])
                try:
                    nomadic_fit[1] = Lion_simulation_fitness.func(Nom_pool, opt_nodes, en, nodes, 100, x_value, y_value)
                except:
                    nomadic_fit[1] = fit(Nom_pool)
                eval = eval + 1
                idx2 = np.argsort(nomadic_fit.T)
                ind = idx2[0]
                ind=ind[0]
                # [elig_fit ind] = min(nomadic_fit)
                elig_fit=nomadic_fit[ind]
                if (elig_fit < male_fit) and (elig_fit < cubpool_malefit) and (elig_fit < cubpool_femalefit):
                    male_in = nomadic_pool[ind,:]
                    male_fit = float(elig_fit[0])
                    cub_age = 0
                    flag1 = 1
                    if ind == 1:
                        nomadic_pool[0,:]=nomadic_pool[1,:]
                        nomadic_fit[0] = nomadic_fit[1]
                else:
                    nomadic_distance1 = np.sqrt((1 / siz) *np.sum((nomadic_pool[0,:] - male_in)** 2))
                    nomadic_distance2 = np.sqrt((1 / siz) * np.sum((nomadic_pool[1,:] - male_in)** 2))
                    distance = [nomadic_distance1, nomadic_distance2]
                    eval1 =np.exp(nomadic_distance1 / np.max(distance)) / (nomadic_fit[0] / np.max(nomadic_fit))
                    if eval1 < np.exp(1):
                        nomadic_pool[0,:]=nomadic_pool[1,:]
                        nomadic_fit[0] = nomadic_fit[1]
                        # Nom_pool = nomadic_pool[1, :].reshape(1, nomadic_pool[1, :].shape[0])
                nom_pool= nomadic_pool[0,:].reshape(1, nomadic_pool[0,:].shape[0])
                nomadic = mutation(nom_pool, 0.15, xmin, xmax)
                tmp_fit = fit( nomadic)
                eval = eval + len(tmp_fit)
                if tmp_fit < nomadic_fit[0]:
                    nomadic_pool[0,:]=nomadic
                    nomadic_fit[0] = tmp_fit

                ##########   Survival Fight   ###########
                ########### Territorial Takeover  ######
                if cub_age > Mature_age:
                    gen = gen + 1
                    flag1 = 1
                    if male_fit > cubpool_malefit:
                        male_in = male_cub
                        male_fit = cubpool_malefit
                    old_female = female_in
                    if female_fit > cubpool_femalefit:
                        female_in = female_cub
                        female_fit = cubpool_femalefit
                    if np.sum(female_in) != np.sum(old_female):
                        mat = 0

            final.append(male_fit)
            gbest = male_in

        g_best=np.random.uniform(0,1,5)
        g_best=g_best.reshape([-1,1]).T

        best = min(final)

        return [best,final]

    # initial population
    def initialize(n):
        data = []
        for i in range(n):
            data.append(random.sample(opt_nodes, nc))  # random nodes to the size of nc
        return data

    M,N,max_eval=3,5,10# M, no.of solution, Max_iter

    init_lion =initialize(N)
    init_lion=np.asarray(init_lion)
    xmin,xmax=0*np.ones([1,N],dtype = int),1*np.ones([1,N],dtype = int)

    # Lion_simulation_fitness.func(init_lion, opt_nodes, en, nodes, 100, x_value, y_value)  # fitness function for Lion
    [best, final] = lion(init_lion, xmin, xmax, max_eval)  # lion optimization

    return final







