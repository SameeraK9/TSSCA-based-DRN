import numpy, random
import Proposed_FLO_DRN_SCA_TSA
import simulation


def phase(rounds, nodes, pop_size):

    # cluster head selection and path selection #
    print("\nEnergy Model..")
    # parameter initialization
    n_cluster = 5  # no. of cluster
    n_nodes = nodes + 1  # no. of nodes(+base station)
    BASE_STATION = n_nodes - 1  # base station -- last node

    # to place nodes over grid
    sq = int(numpy.sqrt(n_nodes))  # to make the nodes in square grid -- take sqrt of nodes
    ex = n_nodes % sq  # excess nodes when make it square grid
    col_n = int((n_nodes - ex) / sq)  # columns for square grid
    m = []
    for i in range(col_n):
        m.append(sq)  # last column with excess nodes
    m.append(ex)

    # creating nodes
    def node_creation(x_value, y_value):
        for x in range(col_n + 1):  # x columns1
            for y in range(m[x]):  # y rows
                px = 50 + x * 60 + random.uniform(-20, 20)  # node in x-axis at px
                x_value.append(px)
                py = 50 + y * 60 + random.uniform(-20, 20)  # node in y-axis at py
                y_value.append(py)

    # initial energy generation
    def generate(v):
        data = []
        for i in range(nodes):
            data.append(v)  # initial energy of all nodes is 1
        return data

    # packets to be send by each node
    def node_packet(nod):
        dp = []
        for i in range(rounds):
            tem = []
            for j in range(nod):
                tem.append(random.randint(1, 10))
            dp.append(tem)
        return dp

    print("\nMobility Model..")
    data_packet = node_packet(nodes)  # packets send by each node
    tr = 0.9
    Xt, Xr = 0.0035, 0.0035  # energy required to send, receive data
    Final_Energy = []      # Final energy,... of the nodes after all rounds

    print("\nCluster Head selection..Please wait..it will take some time(nearly 15-30 minutes)..")

    # Proposed fractional lion optimization  & TSSCA_DRN
    Energy= []
    Energy_avg = []
    ACC, SEN, SPE =[], [], []

    Energy.append(generate(1))

    sr = []

    for i in range(rounds):
        x_value, y_value = [], []  # x & y value of each node
        node_creation(x_value, y_value)  # creating the nodes and get the energy
        en= Proposed_FLO_DRN_SCA_TSA.func(rounds, nodes, n_cluster, Energy[i],data_packet[i],
                                                       x_value, y_value, BASE_STATION, i, pop_size, Xt, Xr, col_n,tr,ACC, SEN, SPE, sr)

        Energy.append(en)
        Energy_avg.append(numpy.average(en))
    Final_Energy.append(Energy_avg[rounds-1])

    simulation.simulation_run(sr[0], sr[1], sr[2], sr[3], sr[4], sr[5], sr[6], sr[7], sr[8], sr[9])




