import numpy as np
from sklearn.model_selection import train_test_split

def BEST(Fit, soln):
    Best, best_soln, bst = Fit[0], soln[0], 0
    for i in range(len(Fit)):
        if(Fit[i] < Best):
            Best = Fit[i]
            best_soln = soln[i]
            bst = i
    return Best, best_soln, bst

def get_data():
    feat=np.load('fin_features.npy')
    lab =np.load('fin_lab.npy')
    return feat, lab

def func(soln):
    ####################### FITNESS CALCULATION using Deep Residual Network#####################
    feat, lab = get_data()
    x_train, x_test, y_train, y_test = train_test_split(feat, lab,
                                                        test_size=1 - 0.7, random_state=123)
    target=np.concatenate((y_train,y_test))
    from Deep_Residual_network import classify

    Fit = []
    for i in range(len(soln)):  # Here, len(soln) represents the dimension of a given problem
        #  get the fitness from deep residual network #
        prop_TSSCA_DRN,acc,_,_ = classify(x_train, y_train, x_test, y_test, soln[i]) # DRN
        fit_tssca_drn = acc
        Fit.append(abs(soln[i] * 1/fit_tssca_drn))

    # Calculate the best fitness value using BEST function
    return BEST(Fit, soln)
